python3 setup.py install
systemctl daemon-reload
systemctl restart osda
systemctl status osda

